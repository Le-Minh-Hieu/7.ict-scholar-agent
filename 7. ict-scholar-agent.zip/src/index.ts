import { YoutubeScraper } from './ingestion/youtube-scraper';
import VideoDownloader from './ingestion/video-downloader';
import { FrameExtractor } from './ingestion/frame-extractor';
import * as dotenv from 'dotenv';
import { ICTPdfGenerator } from './processor/pdf-generator';
import { GoogleGenerativeAI } from "@google/generative-ai";

dotenv.config();

async function runICTAgent() {
    // const scraper = new YoutubeScraper();
    // const downloader = new VideoDownloader();
    // const extractor = new FrameExtractor();
    
    // // Link video ICT thực tế (Tập 1 Mentorship 2022)
    // const videoUrl = 'https://www.youtube.com/watch?v=KzV0_27V0_o';
    // const videoId = scraper.extractVideoId(videoUrl);

    // try {
    //     console.log(`=== BẮT ĐẦU XỬ LÝ VIDEO: ${videoId} ===`);

    //     // BƯỚC 1: Lấy lời giảng (Transcript)
    //     const transcript = await scraper.getTranscript(videoUrl);
    //     scraper.saveToLocal(videoId, transcript);
    //     console.log(`[1/3] Đã lưu ${transcript.length} dòng phụ đề.`);

    //     // BƯỚC 2: Tải Video về ổ D (Để cắt ảnh)
    //     const videoPath = await downloader.downloadVideo(videoUrl, videoId);
    //     console.log(`[2/3] Video đã sẵn sàng tại: ${videoPath}`);

    //     // BƯỚC 3: Chụp thử 1 ảnh tại giây thứ 60 (Minh họa)
    //     console.log(`[3/3] Đang thử nghiệm trích xuất biểu đồ...`);
    //     const sampleImage = await extractor.takeScreenshot(videoPath, 60, videoId);
    //     console.log(`[DONE] Ảnh mẫu đã được lưu tại: ${sampleImage}`);
        
    //     console.log("\n>>> CHÚC MỪNG: HỆ THỐNG INGESTION ĐÃ CHẠY THÔNG SUỐT! <<<");

    // } catch (error) {
    //     console.error("!!! LỖI QUY TRÌNH:", error);
    // }
        const generator = new ICTPdfGenerator();
        
        // Tên file chính xác từ máy của bạn (không bao gồm đuôi .mp4/.srt)
        const videoFileName = "2023 ICT Mentorship - ICT Silver Bullet Time Based Trading Model - (720p)";
        const srtFileName = "2023 ICT Mentorship - ICT Silver Bullet Time Based Trading Model - English -generated) )";

        console.log("--- BẮT ĐẦU QUY TRÌNH XUẤT PDF ---");
        
        try {
            // Chúng ta truyền cả 2 tên file vào nếu chúng khác nhau
            await generator.generateCustom(videoFileName, srtFileName); 
            console.log("--- TẤT CẢ HOÀN TẤT ---");
        } catch (error) {
            console.error("Lỗi trong quá trình thực thi:", error);
        }

//         const genAI = new GoogleGenerativeAI("AIzaSyA4rZI6_V854A_GTGG1k-wSInjXGPOjQ04");

//         async function listModels() {
//         const response = await fetch(`https://generativelanguage.googleapis.com/v1/models?key=${genAI.apiKey}`);
//         const data = await response.json();
//         console.log("Các model bạn có thể dùng:");
//         data.models.forEach(m => console.log("- " + m.name));
//         }
//         listModels();
}

runICTAgent();