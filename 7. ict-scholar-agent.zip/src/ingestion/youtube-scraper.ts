import { createRequire } from 'module';
const require = createRequire(import.meta.url);
import { exec } from 'child_process';
import { promisify } from 'util';
const execPromise = promisify(exec);

import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface ICTTranscript {
    text: string;
    duration: number;
    offset: number;
}

export class YoutubeScraper {
    async getTranscript(videoUrl: string): Promise<any[]> {
            const videoId = this.extractVideoId(videoUrl);
            console.log(`--- Đang lấy phụ đề bằng yt-dlp cho ID: ${videoId} ---`);
            const cookiePath = "D:/7. ict-scholar-agent/www.youtube.com_cookies.txt";
            // Đường dẫn tới yt-dlp (giống bước 1)
            const ytDlpPath = `C:/Users/Administrator/scoop/shims/yt-dlp.exe`;

            try {
                // Lệnh lấy phụ đề tự động và chuyển thành định dạng json
                const { stdout } = await execPromise(`"${ytDlpPath}" --cookies "${cookiePath}" --write-auto-sub --skip-download --sub-format json3 --print-json "${videoUrl}"`);
                const data = JSON.parse(stdout);
                
                if (!data.requested_subtitles || !data.requested_subtitles.en) {
                    console.log("Video này không có phụ đề tiếng Anh.");
                    return [];
                }

                // Trích xuất dữ liệu
                const subs = data.requested_subtitles.en.data.map((item: any) => ({
                    text: item.segs ? item.segs.map((s: any) => s.utf8).join(' ') : '',
                    offset: item.tStartMs,
                    duration: item.dDurationMs
                }));

                return subs;
            } catch (error) {
                console.error("Lỗi yt-dlp transcript:", error);
                return [];
            }
        }

    saveToLocal(videoId: string, data: ICTTranscript[]) {
        const dirPath = path.join(__dirname, '../../data/raw_videos');
        if (!fs.existsSync(dirPath)) {
            fs.mkdirSync(dirPath, { recursive: true });
        }
        const filePath = path.join(dirPath, `${videoId}.json`);
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
        console.log(`=> Đã lưu transcript vào: ${filePath}`);
    }

    extractVideoId(url: string): string {
        const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
        const match = url.match(regExp);
        return (match && match[2].length === 11) ? match[2] : 'unknown';
    }
}