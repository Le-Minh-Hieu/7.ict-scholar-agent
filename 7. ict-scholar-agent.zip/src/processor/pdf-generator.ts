import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import ffmpeg from 'fluent-ffmpeg';
import SrtParser from 'srt-parser-2';
import { GoogleGenerativeAI } from "@google/generative-ai";

// 1. Cấu hình AI - Gemini 2.5 Flash
const genAI = new GoogleGenerativeAI("AIzaSyA4rZI6_V854A_GTGG1k-wSInjXGPOjQ04"); 
const model = genAI.getGenerativeModel(
    { model: "gemini-2.5-flash" },
    { apiVersion: "v1" }
);

const srtParser = new SrtParser();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Đảm bảo đường dẫn FFmpeg chính xác
ffmpeg.setFfmpegPath('C:/Users/Administrator/scoop/shims/ffmpeg.exe');

export class ICTPdfGenerator {
    private readonly rawVideosDir = path.join(__dirname, '../../data/raw_videos');
    private readonly pdfOutputDir = path.join(__dirname, '../../data/pdfs');
    private readonly screenshotsDir = path.join(__dirname, '../../data/screenshots');

    constructor() {
        if (!fs.existsSync(this.pdfOutputDir)) fs.mkdirSync(this.pdfOutputDir, { recursive: true });
        if (!fs.existsSync(this.screenshotsDir)) fs.mkdirSync(this.screenshotsDir, { recursive: true });
    }

    // Hàm AI giữ nguyên logic chuyên gia ICT
    async rewriteWithAI(text: string): Promise<string> {
        const prompt = `
            You are an expert financial editor specializing in ICT (Inner Circle Trader) concepts. 
            Your task: Clean up and rewrite the following raw transcript from an ICT mentorship video.
            STRICT RULES:
            1. LANGUAGE: Use ONLY professional English.
            2. FORMAT: Remove filler words. Fix grammar and punctuation.
            3. TERMINOLOGY: Preserve all ICT technical terms (e.g., FVG, Order Block, Liquidity, Silver Bullet).
            4. STYLE: Rewrite into clear, concise, and educational paragraphs.
            TEXT TO REWRITE: "${text}"
        `;

        try {
            const result = await model.generateContent(prompt);
            const response = await result.response;
            return response.text().trim();
        } catch (error: any) {
            if (error.status === 429) {
                console.log("⚠️ Quota limit. Waiting 60s...");
                await new Promise(res => setTimeout(res, 60000));
                return this.rewriteWithAI(text);
            }
            return text; // Trả về text gốc nếu AI lỗi
        }
    }

    async generateCustom(videoName: string, srtName: string) {
        const videoPath = path.join(this.rawVideosDir, `${videoName}.mp4`);
        const srtPath = path.join(this.rawVideosDir, `${srtName}.srt`);
        const safeFileName = videoName.substring(0, 50).replace(/[\\/:*?"<>|]/g, '_');
        const pdfPath = path.join(this.pdfOutputDir, `${safeFileName}_HandBook.pdf`);

        if (!fs.existsSync(videoPath) || !fs.existsSync(srtPath)) {
            console.error(`❌ Không tìm thấy file gốc!`);
            return;
        }

        const subtitles = srtParser.fromSrt(fs.readFileSync(srtPath, 'utf8'));
        const doc = new PDFDocument({ margin: 50, size: 'A4' });
        const stream = fs.createWriteStream(pdfPath);
        doc.pipe(stream);

        let lastSize = 0;
        const createdFiles: string[] = []; // Danh sách để theo dõi và xóa sau này

        console.log(`🚀 Processing: ${videoName}...`);

        for (let i = 0; i < subtitles.length; i += 4) {
            const sub = subtitles[i];
            const timestamp = this.timeToSeconds(sub.startTime);
            const screenshotName = `temp_frame_${i}.jpg`;
            const screenshotPath = path.join(this.screenshotsDir, screenshotName);

            // 1. Chỉ chụp ảnh nếu chưa tồn tại (Cache logic)
            if (!fs.existsSync(screenshotPath)) {
                await new Promise((resolve) => {
                    ffmpeg(videoPath)
                        .screenshots({
                            timestamps: [timestamp],
                            filename: screenshotName,
                            folder: this.screenshotsDir,
                            size: '1280x720'
                        })
                        .on('end', resolve)
                        .on('error', resolve);
                });
                createdFiles.push(screenshotPath); // Lưu lại đường dẫn để xóa
            }

            const rawSegmentText = subtitles.slice(i, i + 4).map((s: any) => s.text).join(" ").replace(/\s+/g, ' ');
            const polishedText = await this.rewriteWithAI(rawSegmentText);
            const currentSize = fs.existsSync(screenshotPath) ? fs.statSync(screenshotPath).size : 0;
            
            // Logic so sánh bạn đang ưng ý
            const isDifferent = Math.abs(currentSize - lastSize) > 1500;

            if (i === 0 || isDifferent) {
                doc.addPage();
                doc.fillColor('#f0f0f0').rect(50, 40, 495, 20).fill();
                doc.fillColor('#0047ab').font('Helvetica-Bold').fontSize(10).text(`TIMEMARK: ${sub.startTime}`, 60, 47);

                if (fs.existsSync(screenshotPath)) {
                    doc.image(screenshotPath, 50, 70, { width: 495 });
                }

                doc.y = 360; 
                doc.fillColor('#333333').font('Helvetica').fontSize(10).text(polishedText, {
                    width: 495, align: 'justify', lineGap: 2
                });
                lastSize = currentSize;
            } else {
                if (doc.y > 700) { doc.addPage(); doc.y = 50; }
                doc.moveDown(1);
                doc.fillColor('#666666').font('Helvetica-Oblique').fontSize(9).text(`[Cont.]: ${polishedText}`, { width: 495, align: 'justify' });
            }

            console.log(`Tiến độ: ${sub.startTime}`);
            await new Promise(res => setTimeout(res, 1500)); // Tối ưu tốc độ một chút
        }

        doc.end();

        return new Promise((res) => {
            stream.on('finish', () => {
                console.log(`✅ Xuất thành công: ${pdfPath}`);
                
                // --- BƯỚC CLEAN UP ---
                console.log(`🧹 Đang dọn dẹp ${createdFiles.length} file ảnh tạm...`);
                createdFiles.forEach(file => {
                    if (fs.existsSync(file)) fs.unlinkSync(file);
                });
                console.log(`✨ Server đã sạch sẽ!`);
                
                res(true);
            });
        });
    }

    private timeToSeconds(t: string): number {
        const a = t.split(':');
        const secondsPart = a[2].includes(',') ? a[2].split(',')[0] : a[2].split('.')[0];
        return (+a[0]) * 3600 + (+a[1]) * 60 + (+secondsPart);
    }
}